<template>
    <div>
        <GpsChild />
    </div>
</template>

<script setup>
import GpsChild from './components/GpsChild.vue';

</script>

<style scoped>

</style>